package ro.capemaker;

import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;

public final class CapeMakerScreen extends Screen {
    private final Path capePath = FabricLoader.getInstance()
            .getConfigDir().resolve("capemaker").resolve("cape.png");
    private String status = "PNG-ul se pune in config/capemaker/cape.png";

    public CapeMakerScreen() {
        super(Text.literal("CapeMaker"));
    }

    @Override
    protected void init() {
        int center = this.width / 2;
        int y = this.height / 2 - 5;

        addDrawableChild(ButtonWidget.builder(
                Text.literal("Verifica / reincarca PNG"),
                button -> checkPng()
        ).dimensions(center - 100, y, 200, 20).build());

        addDrawableChild(ButtonWidget.builder(
                Text.literal("Inchide"),
                button -> close()
        ).dimensions(center - 100, y + 28, 200, 20).build());
    }

    private void checkPng() {
        try {
            Files.createDirectories(capePath.getParent());
            if (!Files.exists(capePath)) {
                status = "Lipseste PNG-ul. Copiaza imaginea aici:";
                return;
            }
            BufferedImage image = ImageIO.read(capePath.toFile());
            if (image == null) {
                status = "Fisierul nu este un PNG valid.";
            } else if (image.getWidth() != 64 || image.getHeight() != 32) {
                status = "PNG gasit, dar dimensiunea este " + image.getWidth()
                        + "x" + image.getHeight() + ". Recomandat: 64x32.";
            } else {
                status = "PNG valid: 64x32. Afisarea pe personaj nu este implementata in prototip.";
            }
        } catch (IOException e) {
            status = "Nu pot citi PNG-ul: verifica permisiunile si fisierul.";
        }
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        renderBackground(context, mouseX, mouseY, delta);
        context.drawCenteredTextWithShadow(textRenderer, title, width / 2, height / 2 - 65, 0xFFFFFF);
        context.drawCenteredTextWithShadow(textRenderer, Text.literal(status), width / 2, height / 2 - 35, 0xFFFFFF);
        context.drawCenteredTextWithShadow(textRenderer, Text.literal("Fisier: config/capemaker/cape.png"), width / 2, height / 2 - 22, 0xBBBBBB);
        context.drawCenteredTextWithShadow(textRenderer, Text.literal("Deschide cu tasta K (sau schimba tasta in Controls)."), width / 2, height / 2 + 60, 0xBBBBBB);
        super.render(context, mouseX, mouseY, delta);
    }

    @Override
    public boolean shouldPause() {
        return false;
    }
}
